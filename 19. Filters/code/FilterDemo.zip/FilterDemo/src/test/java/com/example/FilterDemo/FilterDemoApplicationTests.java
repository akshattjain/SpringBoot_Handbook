package com.example.FilterDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilterDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
